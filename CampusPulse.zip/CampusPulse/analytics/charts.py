import matplotlib.pyplot as plt

CHART_COLORS = [
    "#243B6B",
    "#315D96",
    "#4169A1",
    "#567BB5",
    "#718FC4",
    "#8FA9D2",
    "#A9BCE0",
    "#C5D3EA"
]


def create_donut_chart(values, labels, title):

    fig, ax = plt.subplots(figsize=(3.4, 2.7))

    fig.patch.set_facecolor("#FFFFFF")
    ax.set_facecolor("#FFFFFF")

    if sum(values) == 0:
        ax.text(
            0.5, 0.5,
            "No data available",
            ha="center",
            va="center",
            fontsize=10
        )
        ax.axis("off")
        return fig

    wedges, texts, autotexts = ax.pie(
        values,
        colors=CHART_COLORS[:len(values)],
        startangle=90,
        autopct="%1.1f%%",
        pctdistance=0.65,
        radius=0.78,
        wedgeprops={
            "edgecolor": "white",
            "linewidth": 1.5
        },
        textprops={"fontsize": 8}
    )

    for text in autotexts:
        text.set_color("#FFFFFF")
        text.set_fontweight("bold")
        text.set_fontsize(8)

    ax.legend(
        wedges,
        labels,
        loc="center left",
        bbox_to_anchor=(0.88, 0.5),
        frameon=False,
        fontsize=7
    )

    ax.set_title(
        title,
        fontsize=10,
        fontweight="bold",
        color="#192D50",
        pad=8
    )

    ax.axis("equal")
    plt.tight_layout()

    return fig
def create_bar_chart(data, title, x_label, y_label):

    fig, ax = plt.subplots(figsize=(4.5, 2.8))

    fig.patch.set_facecolor("#FFFFFF")
    ax.set_facecolor("#FFFFFF")

    if data.empty:
        ax.text(
            0.5, 0.5,
            "No data available",
            ha="center",
            va="center"
        )
        ax.axis("off")
        return fig

    bars = ax.bar(
        data.iloc[:, 0].astype(str),
        data.iloc[:, 1],
        color=CHART_COLORS[:len(data)],
        width=0.58
    )

    ax.bar_label(bars, padding=3, fontsize=8)

    ax.set_title(
        title,
        fontsize=11,
        fontweight="bold",
        color="#192D50"
    )

    ax.set_xlabel(x_label, fontsize=8)
    ax.set_ylabel(y_label, fontsize=8)

    ax.tick_params(axis="x", labelrotation=20, labelsize=8)
    ax.tick_params(axis="y", labelsize=8)

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    ax.grid(axis="y", alpha=0.15)

    plt.tight_layout()

    return fig
