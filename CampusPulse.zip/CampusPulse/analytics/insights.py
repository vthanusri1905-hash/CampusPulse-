def generate_insights(metrics, department_data, company_data):

    insights = []

    rate = metrics["placement_rate"]
    average = metrics["average_package"]
    highest = metrics["highest_package"]

    if rate >= 80:
        insights.append(
            "Strong placement performance: the placement rate is 80% or higher."
        )
    elif rate >= 50:
        insights.append(
            "Moderate placement performance: there is room to improve the placement rate."
        )
    else:
        insights.append(
            "Placement performance needs attention. Focus on eligible students who are not yet placed."
        )

    if average > 0:
        insights.append(
            f"The average successful placement package is {average:.2f} LPA."
        )

    if highest > 0:
        insights.append(
            f"The highest recorded successful placement package is {highest:.2f} LPA."
        )

    if not department_data.empty:
        best_department = department_data.sort_values(
            "placement_rate",
            ascending=False
        ).iloc[0]

        insights.append(
            f"{best_department['department']} has the highest department placement rate at {best_department['placement_rate']:.1f}%."
        )

    if not company_data.empty:
        best_company = company_data.sort_values(
            "average_package",
            ascending=False
        ).iloc[0]

        insights.append(
            f"{best_company['company']} offers the highest average package among recorded companies at {best_company['average_package']:.2f} LPA."
        )

    return insights