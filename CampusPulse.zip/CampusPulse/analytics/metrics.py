import pandas as pd


def calculate_placement_metrics(students, placements):

    total_students = len(students)

    eligible_students = int(
        students["eligible_for_placement"].sum()
    ) if not students.empty else 0

    successful = placements[
        placements["status"] == "Placed"
    ].copy()

    placed_students = successful["roll_no"].nunique()

    not_placed = max(
        eligible_students - placed_students, 0
    )

    placement_rate = (
        placed_students / eligible_students * 100
        if eligible_students > 0 else 0
    )

    packages = pd.to_numeric(
        successful["package_lpa"],
        errors="coerce"
    ).dropna()

    average_package = (
        float(packages.mean()) if not packages.empty else 0
    )

    median_package = (
        float(packages.median()) if not packages.empty else 0
    )

    highest_package = (
        float(packages.max()) if not packages.empty else 0
    )

    return {
        "total_students": total_students,
        "eligible_students": eligible_students,
        "placed_students": placed_students,
        "not_placed": not_placed,
        "placement_rate": placement_rate,
        "average_package": average_package,
        "median_package": median_package,
        "highest_package": highest_package
    }