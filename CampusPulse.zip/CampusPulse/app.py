import streamlit as st
from pathlib import Path

from database.queries import (
    get_students,
    get_placements,
    get_skills,
    get_department_analytics,
    get_company_analytics
)

from analytics.metrics import calculate_placement_metrics
from modules.dashboard import show_dashboard
from modules.students import show_student_management
from modules.placements import show_placement_management

st.set_page_config(
    page_title="CampusPulse | Placement Intelligence",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)


# LOAD DESIGN
css_path = Path("assets/css/style.css")

if css_path.exists():
    with open(css_path, "r", encoding="utf-8") as file:
        st.markdown(
            f"<style>{file.read()}</style>",
            unsafe_allow_html=True
        )


# SIDEBAR
with st.sidebar:

    st.markdown("# 🎓 CampusPulse")
    st.caption("PLACEMENT INTELLIGENCE")
    st.markdown("---")

    page = st.radio(
        "NAVIGATION",
        [
            "Dashboard",
            "Student Management",
            "Placement Management",
            "Skills Analytics",
            "Reports"
        ]
    )

    st.markdown("---")
    st.caption("Turning Placement Data into Career Insights")
    st.caption("Academic Demo Portal")


# DATABASE
try:

    students = get_students()
    placements = get_placements()
    skills = get_skills()

    department_data = get_department_analytics()
    company_data = get_company_analytics()

    metrics = calculate_placement_metrics(
        students,
        placements
    )

    # DASHBOARD
    if page == "Dashboard":

        show_dashboard(
            students,
            placements,
            skills,
            metrics,
            department_data,
            company_data
        )

    elif page == "Student Management":

        show_student_management(students)
    elif page == "Placement Management":

        show_placement_management(students, placements)

    elif page == "Skills Analytics":

        st.title("Skills Analytics")

        if not skills.empty:
            st.bar_chart(
                skills.set_index("skill_name"),
                color="#8064B5"
            )

            st.dataframe(
                skills,
                use_container_width=True,
                hide_index=True
            )
        else:
            st.info("No skill records available.")

    elif page == "Reports":

        st.title("Placement Reports")

        st.dataframe(
            placements,
            use_container_width=True,
            hide_index=True
        )

        st.download_button(
            "Download Placement Report",
            data=placements.to_csv(index=False).encode("utf-8"),
            file_name="CampusPulse_Placement_Report.csv",
            mime="text/csv"
        )

        st.download_button(
            "Download Student Report",
            data=students.to_csv(index=False).encode("utf-8"),
            file_name="CampusPulse_Student_Report.csv",
            mime="text/csv"
        )

    st.markdown("---")
    st.caption("CampusPulse | Placement Analytics Portal")


except Exception as e:

    st.error("Unable to load CampusPulse.")
    st.exception(e)