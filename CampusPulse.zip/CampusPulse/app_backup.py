

import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from database.connection import get_connection

st.set_page_config(
    page_title="CampusPulse | Placement Cell",
    page_icon="🎓",
    layout="wide"
)

# ---------------- DESIGN ----------------

st.markdown("""
<style>
.stApp {
    background: #F3F6FB;
    color: #1B2942;
}
.block-container {
    padding: 1.5rem 2.5rem;
    max-width: 1500px;
}
[data-testid="stSidebar"] {
    background: #14243E;
}
[data-testid="stSidebar"] * {
    color: #EAF1FC !important;
}
[data-testid="stSidebar"] [data-testid="stMarkdownContainer"] p {
    color: #B8C7DF !important;
}
[data-testid="stMetric"] {
    background: white;
    border: 1px solid #DFE6F0;
    padding: 16px;
    border-radius: 12px;
    box-shadow: 0 3px 12px rgba(20,36,62,0.05);
}
[data-testid="stMetricLabel"] {
    color: #64748B;
}
[data-testid="stMetricValue"] {
    color: #244B80;
}
.stButton button {
    background: #315D96;
    color: white;
    border-radius: 8px;
    border: none;
}
.stButton button:hover {
    background: #244675;
    color: white;
}
h1, h2, h3 {
    color: #172B4D;
}
div[data-testid="stDataFrame"] {
    border: 1px solid #DFE6F0;
    border-radius: 10px;
}
</style>
""", unsafe_allow_html=True)


# ---------------- DATABASE ----------------

connection = get_connection()

if not connection:
    st.error("Database connection failed. Check your MySQL connection.")
    st.stop()


def read_data(query, params=None):
    cursor = connection.cursor()
    cursor.execute(query, params or ())
    rows = cursor.fetchall()
    columns = [item[0] for item in cursor.description]
    cursor.close()
    return pd.DataFrame(rows, columns=columns)


def execute_query(query, params):
    cursor = connection.cursor()
    cursor.execute(query, params)
    connection.commit()
    cursor.close()


# ---------------- SIDEBAR ----------------

with st.sidebar:
    st.markdown("# 🎓 CampusPulse")
    st.caption("PLACEMENT CELL PORTAL")
    st.markdown("---")

    page = st.radio(
        "MAIN MENU",
        [
            "Dashboard",
            "Student Management",
            "Placement Management",
            "Skills Analytics",
            "Reports"
        ]
    )

    st.markdown("---")
    st.markdown("**MOHAN BABU UNIVERSITY**")
    st.caption("Student Placement Analytics")
    st.caption("Academic Demo Portal")


# ---------------- LOAD DATA ----------------

try:
    students = read_data("""
        SELECT student_id, roll_no, department,
               graduation_year, eligible_for_placement
        FROM students
        ORDER BY student_id
    """)

    placements = read_data("""
        SELECT p.placement_id, s.roll_no, s.department,
               p.company, p.job_role, p.package_lpa,
               p.placement_date, p.status
        FROM placements p
        JOIN students s ON p.student_id = s.student_id
        ORDER BY p.placement_date DESC
    """)

    skills = read_data("""
        SELECT sk.skill_name, COUNT(*) AS student_count
        FROM student_skills ss
        JOIN skills sk ON ss.skill_id = sk.skill_id
        GROUP BY sk.skill_name
        ORDER BY student_count DESC
    """)

    total_students = len(students)
    eligible = int(students["eligible_for_placement"].sum())

    placed = placements.loc[
        placements["status"] == "Placed", "roll_no"
    ].nunique()

    placement_rate = (
        placed / eligible * 100 if eligible else 0
    )

    packages = pd.to_numeric(
        placements.loc[
            placements["status"] == "Placed", "package_lpa"
        ],
        errors="coerce"
    ).dropna()

    average_package = packages.mean() if not packages.empty else 0
    highest_package = packages.max() if not packages.empty else 0

    # ---------------- DASHBOARD ----------------

    if page == "Dashboard":

        st.title("Placement Dashboard")
        st.caption(
            "Welcome to the CampusPulse Placement Cell Management Portal."
        )

        st.markdown("---")
        st.subheader("Key Performance Indicators")

        c1, c2, c3, c4 = st.columns(4)

        c1.metric("Total Students", total_students)
        c2.metric("Eligible Students", eligible)
        c3.metric("Students Placed", placed)
        c4.metric("Placement Rate", f"{placement_rate:.1f}%")

        c5, c6 = st.columns(2)
        c5.metric("Average Package", f"{average_package:.2f} LPA")
        c6.metric("Highest Package", f"{highest_package:.2f} LPA")

        st.markdown("---")
        st.subheader("Placement Analytics")

        left, right = st.columns(2)

        with left:
            st.markdown("**Student Placement Status**")

            not_placed = max(eligible - placed, 0)

            fig, ax = plt.subplots(figsize=(5, 4))
            fig.patch.set_facecolor("white")

            if eligible > 0:
                ax.pie(
                    [placed, not_placed],
                    labels=["Placed", "Not Placed"],
                    autopct="%1.1f%%",
                    startangle=90,
                    colors=["#4169A1", "#DCE6F3"],
                    wedgeprops={"width": 0.42}
                )
            else:
                ax.text(0.5, 0.5, "No eligible students",
                        ha="center", va="center")

            ax.set_title("Placement Distribution")
            st.pyplot(fig)
            plt.close(fig)

        with right:
            st.markdown("**Department-wise Student Distribution**")

            dept_counts = students["department"].value_counts()

            fig, ax = plt.subplots(figsize=(5, 4))
            fig.patch.set_facecolor("white")

            if not dept_counts.empty:
                ax.pie(
                    dept_counts.values,
                    labels=dept_counts.index,
                    autopct="%1.1f%%",
                    startangle=90,
                    colors=["#4169A1", "#77A6D9",
                            "#A9C7E8", "#D8E5F5",
                            "#899CB8"]
                )

            ax.set_title("Department Distribution")
            st.pyplot(fig)
            plt.close(fig)

        st.markdown("---")

        left, right = st.columns(2)

        with left:
            st.markdown("**Department Placement Comparison**")

            dept_data = read_data("""
                SELECT s.department,
                       COUNT(DISTINCT CASE
                           WHEN p.status = 'Placed'
                           THEN s.student_id END) AS placed
                FROM students s
                LEFT JOIN placements p
                ON s.student_id = p.student_id
                GROUP BY s.department
            """)

            st.bar_chart(
                dept_data.set_index("department"),
                color="#4169A1"
            )

        with right:
            st.markdown("**Average Package by Company**")

            company_data = read_data("""
                SELECT company,
                       AVG(package_lpa) AS average_package
                FROM placements
                WHERE status = 'Placed'
                GROUP BY company
            """)

            if not company_data.empty:
                st.bar_chart(
                    company_data.set_index("company"),
                    color="#77A6D9"
                )
            else:
                st.info("No package information available.")

        st.markdown("---")
        st.subheader("Recent Placement Records")

        st.dataframe(
            placements.head(8),
            use_container_width=True,
            hide_index=True
        )


    # ---------------- STUDENT MANAGEMENT ----------------

    elif page == "Student Management":

        st.title("Student Management")
        st.caption("Register, view and manage student information.")

        tab1, tab2, tab3 = st.tabs([
            "All Students",
            "Add Student",
            "Delete Student"
        ])

        with tab1:
            st.subheader("Registered Students")

            search = st.text_input(
                "Search by Roll Number or Department"
            )

            filtered = students.copy()

            if search:
                filtered = filtered[
                    filtered["roll_no"].astype(str).str.contains(
                        search, case=False
                    )
                    | filtered["department"].astype(str).str.contains(
                        search, case=False
                    )
                ]

            st.dataframe(
                filtered,
                use_container_width=True,
                hide_index=True
            )

        with tab2:
            st.subheader("Register New Student")

            with st.form("add_student_form"):

                roll_no = st.text_input("Roll Number")
                department = st.selectbox(
                    "Department",
                    ["CSE", "AI & DS", "ECE", "EEE", "Mechanical", "Civil"]
                )

                year = st.selectbox(
                    "Graduation Year",
                    [2026, 2027, 2028, 2029, 2030]
                )

                eligible_value = st.checkbox(
                    "Eligible for Placement", value=True
                )

                submitted = st.form_submit_button("Add Student")

                if submitted:
                    if not roll_no.strip():
                        st.error("Please enter a roll number.")
                    else:
                        try:
                            execute_query("""
                                INSERT INTO students
                                (roll_no, department, graduation_year,
                                 eligible_for_placement)
                                VALUES (%s, %s, %s, %s)
                            """, (
                                roll_no.strip(),
                                department,
                                year,
                                eligible_value
                            ))

                            st.success("Student added successfully!")
                            st.rerun()

                        except Exception as e:
                            st.error(f"Unable to add student: {e}")

        with tab3:
            st.subheader("Delete Student Record")

            if not students.empty:

                student_options = {
                    f"{row.roll_no} - {row.department}":
                    int(row.student_id)
                    for row in students.itertuples()
                }

                selected = st.selectbox(
                    "Select Student",
                    list(student_options.keys())
                )

                confirm = st.checkbox(
                    "I confirm that I want to permanently delete this student and related records."
                )

                if st.button("Delete Student"):
                    if confirm:
                        student_id = student_options[selected]

                        try:
                            cursor = connection.cursor()
                            connection.start_transaction()

                            cursor.execute(
                                "DELETE FROM placements WHERE student_id = %s",
                                (student_id,)
                            )

                            cursor.execute(
                                "DELETE FROM student_skills WHERE student_id = %s",
                                (student_id,)
                            )

                            cursor.execute(
                                "DELETE FROM students WHERE student_id = %s",
                                (student_id,)
                            )

                            connection.commit()
                            cursor.close()

                            st.success("Student and related records deleted.")
                            st.rerun()

                        except Exception as e:
                            connection.rollback()
                            st.error(f"Deletion failed: {e}")
                    else:
                        st.warning("Please confirm before deleting.")
            else:
                st.info("No students available.")


    # ---------------- PLACEMENT MANAGEMENT ----------------

    elif page == "Placement Management":

        st.title("Placement Management")
        st.caption("Manage recruitment and placement records.")

        tab1, tab2 = st.tabs([
            "All Placement Records",
            "Add Placement"
        ])

        with tab1:
            st.dataframe(
                placements,
                use_container_width=True,
                hide_index=True
            )

        with tab2:
            if not students.empty:

                student_options = {
                    f"{row.roll_no} - {row.department}":
                    int(row.student_id)
                    for row in students.itertuples()
                }

                with st.form("placement_form"):

                    student = st.selectbox(
                        "Select Student",
                        list(student_options.keys())
                    )

                    company = st.text_input("Company Name")
                    role = st.text_input("Job Role")

                    package = st.number_input(
                        "Package (LPA)",
                        min_value=0.0,
                        step=0.5
                    )

                    placement_date = st.date_input(
                        "Placement Date"
                    )

                    status = st.selectbox(
                        "Placement Status",
                        ["Applied", "Interview", "Offered",
                         "Placed", "Rejected", "Withdrawn"]
                    )

                    submitted = st.form_submit_button(
                        "Save Placement"
                    )

                    if submitted:
                        if not company.strip() or not role.strip():
                            st.error("Enter company and job role.")
                        elif status == "Placed" and package <= 0:
                            st.error(
                                "A successful placement requires a package."
                            )
                        else:
                            try:
                                execute_query("""
                                    INSERT INTO placements
                                    (student_id, company, job_role,
                                     package_lpa, placement_date, status)
                                    VALUES (%s, %s, %s, %s, %s, %s)
                                """, (
                                    student_options[student],
                                    company.strip(),
                                    role.strip(),
                                    package if package > 0 else None,
                                    placement_date,
                                    status
                                ))

                                st.success("Placement record saved!")
                                st.rerun()

                            except Exception as e:
                                st.error(f"Unable to save record: {e}")
            else:
                st.info("Add students before creating placement records.")


    # ---------------- SKILLS ANALYTICS ----------------

    elif page == "Skills Analytics":

        st.title("Skills Analytics")
        st.caption("Understand the skills represented in student profiles.")

        if not skills.empty:

            st.subheader("Most Common Student Skills")

            st.bar_chart(
                skills.set_index("skill_name"),
                color="#4169A1"
            )

            st.dataframe(
                skills,
                use_container_width=True,
                hide_index=True
            )

            fig, ax = plt.subplots(figsize=(6, 5))
            ax.pie(
                skills["student_count"],
                labels=skills["skill_name"],
                autopct="%1.1f%%",
                startangle=90
            )
            ax.set_title("Skill Distribution")
            st.pyplot(fig)
            plt.close(fig)

        else:
            st.info("No skill records available.")


    # ---------------- REPORTS ----------------

    elif page == "Reports":

        st.title("Placement Reports")
        st.caption("View and export college placement information.")

        st.subheader("Placement Summary")

        a, b, c = st.columns(3)
        a.metric("Students", total_students)
        b.metric("Placed", placed)
        c.metric("Placement Rate", f"{placement_rate:.1f}%")

        st.subheader("Placement Data")

        st.dataframe(
            placements,
            use_container_width=True,
            hide_index=True
        )

        csv = placements.to_csv(index=False).encode("utf-8")

        st.download_button(
            "Download Placement Report",
            data=csv,
            file_name="CampusPulse_Placement_Report.csv",
            mime="text/csv"
        )

        student_csv = students.to_csv(index=False).encode("utf-8")

        st.download_button(
            "Download Student Report",
            data=student_csv,
            file_name="CampusPulse_Student_Report.csv",
            mime="text/csv"
        )

    st.markdown("---")
    st.caption(
        "CampusPulse | Mohan Babu University | Placement Cell"
    )

except Exception as e:
    st.error(f"Application error: {e}")

finally:
    connection.close()
