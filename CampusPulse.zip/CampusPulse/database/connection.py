
import mysql.connector
from mysql.connector import Error


def get_connection():
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="thanu",
            database="campuspulse_db"
        )

        if connection.is_connected():
            return connection

    except Error as e:
        print("Database connection error:", e)

    return None
