import pandas as pd
from database.connection import get_connection


def fetch_data(query, params=None):

    connection = get_connection()

    if connection is None:
        raise ConnectionError("Unable to connect to CampusPulse database.")

    cursor = None

    try:
        cursor = connection.cursor()
        cursor.execute(query, params or ())

        rows = cursor.fetchall()
        columns = [item[0] for item in cursor.description]

        return pd.DataFrame(rows, columns=columns)

    finally:
        if cursor:
            cursor.close()
        connection.close()


def get_students():

    return fetch_data("""
        SELECT student_id, roll_no, department,
               graduation_year, eligible_for_placement
        FROM students
        ORDER BY student_id DESC
    """)


def get_placements():

    return fetch_data("""
        SELECT p.placement_id, s.student_id, s.roll_no,
               s.department, p.company, p.job_role,
               p.package_lpa, p.placement_date, p.status
        FROM placements p
        JOIN students s ON p.student_id = s.student_id
        ORDER BY p.placement_date DESC
    """)


def get_skills():

    return fetch_data("""
        SELECT sk.skill_name,
               COUNT(DISTINCT ss.student_id) AS student_count
        FROM skills sk
        LEFT JOIN student_skills ss
        ON sk.skill_id = ss.skill_id
        GROUP BY sk.skill_id, sk.skill_name
        ORDER BY student_count DESC
    """)


def get_department_analytics():

    return fetch_data("""
        SELECT
            s.department,
            COUNT(DISTINCT s.student_id) AS eligible_students,
            COUNT(DISTINCT CASE
                WHEN p.status = 'Placed'
                THEN s.student_id
            END) AS placed_students,
            ROUND(
                COUNT(DISTINCT CASE
                    WHEN p.status = 'Placed'
                    THEN s.student_id
                END) * 100.0 /
                NULLIF(COUNT(DISTINCT s.student_id), 0),
                2
            ) AS placement_rate
        FROM students s
        LEFT JOIN placements p
            ON s.student_id = p.student_id
        WHERE s.eligible_for_placement = 1
        GROUP BY s.department
        ORDER BY placement_rate DESC
    """)


def get_company_analytics():

    return fetch_data("""
        SELECT
            company,
            COUNT(DISTINCT student_id) AS students_placed,
            ROUND(AVG(package_lpa), 2) AS average_package,
            MAX(package_lpa) AS highest_package
        FROM placements
        WHERE status = 'Placed'
        GROUP BY company
        ORDER BY average_package DESC
    """)