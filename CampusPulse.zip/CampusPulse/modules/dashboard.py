import streamlit as st
import matplotlib.pyplot as plt

from analytics.charts import create_donut_chart, create_bar_chart
from analytics.insights import generate_insights


def show_dashboard_header():

    st.markdown("""
    <div style="
        background: linear-gradient(110deg, #172B4D, #315D96, #6656A6);
        padding: 25px 30px;
        border-radius: 16px;
        margin-bottom: 22px;
    ">
        <div style="color:#C9D8F2;font-size:13px;
                    font-weight:600;letter-spacing:2px;">
            PLACEMENT INTELLIGENCE PLATFORM
        </div>
        <div style="color:white;font-size:30px;
                    font-weight:750;margin-top:7px;">
            CampusPulse
        </div>
        <div style="color:#E0E9FA;font-size:14px;margin-top:5px;">
            Turning Placement Data into Career Insights
        </div>
    </div>
    """, unsafe_allow_html=True)


def show_dashboard(
    students,
    placements,
    skills,
    metrics,
    department_data,
    company_data
):

    show_dashboard_header()

    st.subheader("Executive Overview")

    c1, c2, c3, c4 = st.columns(4)

    c1.metric(
        "Total Students",
        metrics["total_students"]
    )

    c2.metric(
        "Eligible Students",
        metrics["eligible_students"]
    )

    c3.metric(
        "Students Placed",
        metrics["placed_students"]
    )

    c4.metric(
        "Placement Rate",
        f'{metrics["placement_rate"]:.1f}%'
    )

    c5, c6, c7 = st.columns(3)

    c5.metric(
        "Average Package",
        f'{metrics["average_package"]:.2f} LPA'
    )

    c6.metric(
        "Median Package",
        f'{metrics["median_package"]:.2f} LPA'
    )

    c7.metric(
        "Highest Package",
        f'{metrics["highest_package"]:.2f} LPA'
    )

    st.markdown("---")
    st.subheader("Placement Intelligence")

    left, right = st.columns(2)

    with left:

        fig = create_donut_chart(
            [
                metrics["placed_students"],
                metrics["not_placed"]
            ],
            ["Placed", "Not Yet Placed"],
            "Eligible Student Outcomes"
        )

        st.pyplot(fig, use_container_width=True)
        plt.close(fig)

    with right:

        department_counts = (
            students["department"].value_counts()
        )

        fig = create_donut_chart(
            department_counts.values.tolist(),
            department_counts.index.tolist(),
            "Student Distribution by Department"
        )

        st.pyplot(fig, use_container_width=False)
        plt.close(fig)

    st.markdown("---")
    st.subheader("Department Performance")

    if not department_data.empty:

        fig = create_bar_chart(
            department_data[
                ["department", "placement_rate"]
            ],
            "Department Placement Rate",
            "Department",
            "Placement Rate (%)"
        )

        st.pyplot(fig, use_container_width=True)
        plt.close(fig)

        st.dataframe(
            department_data,
            use_container_width=True,
            hide_index=True
        )

    else:
        st.info("No department analytics available.")

    st.markdown("---")
    st.subheader("Company Package Analysis")

    if not company_data.empty:

        fig = create_bar_chart(
            company_data[
                ["company", "average_package"]
            ],
            "Average Package by Company",
            "Company",
            "Average Package (LPA)"
        )

        st.pyplot(fig, use_container_width=True)
        plt.close(fig)

        st.dataframe(
            company_data,
            use_container_width=True,
            hide_index=True
        )

    else:
        st.info("No successful placement records available.")

    st.markdown("---")
    st.subheader("Automated Placement Insights")

    insights = generate_insights(
        metrics,
        department_data,
        company_data
    )

    for insight in insights:
        st.info(insight)

    st.markdown("---")
    st.subheader("Recent Placement Activity")

    if not placements.empty:

        st.dataframe(
            placements.head(8),
            use_container_width=True,
            hide_index=True
        )

    else:
        st.info("No placement records available.")

    st.caption(
        "Placement rate = Successfully placed eligible students "
        "/ Total eligible students × 100"
    )