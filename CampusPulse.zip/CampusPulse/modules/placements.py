import streamlit as st
from datetime import date
from database.connection import get_connection

def add_placement(
    student_id,
    company,
    job_role,
    package_lpa,
    placement_date,
    status
):

    connection = get_connection()

    if connection is None:
        raise ConnectionError("Database connection failed.")

    cursor = None

    try:
        cursor = connection.cursor()

        cursor.execute("""
            INSERT INTO placements
            (student_id, company, job_role, package_lpa,
             placement_date, status)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (
            student_id,
            company,
            job_role,
            package_lpa,
            placement_date,
            status
        ))

        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        if cursor:
            cursor.close()
        connection.close()


def update_placement(
    placement_id,
    company,
    job_role,
    package_lpa,
    placement_date,
    status
):

    connection = get_connection()

    if connection is None:
        raise ConnectionError("Database connection failed.")

    cursor = None

    try:
        cursor = connection.cursor()

        cursor.execute("""
            UPDATE placements
            SET company = %s,
                job_role = %s,
                package_lpa = %s,
                placement_date = %s,
                status = %s
            WHERE placement_id = %s
        """, (
            company,
            job_role,
            package_lpa,
            placement_date,
            status,
            placement_id
        ))

        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        if cursor:
            cursor.close()
        connection.close()


def delete_placement(placement_id):

    connection = get_connection()

    if connection is None:
        raise ConnectionError("Database connection failed.")

    cursor = None

    try:
        cursor = connection.cursor()

        cursor.execute(
            "DELETE FROM placements WHERE placement_id = %s",
            (placement_id,)
        )

        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        if cursor:
            cursor.close()
        connection.close()
def show_placement_management(students, placements):

    st.title("Placement Management")
    st.caption("Track applications, offers and successful placements.")

    tab1, tab2, tab3 = st.tabs([
        "Add Placement",
        "Manage Records",
        "Delete Record"
    ])

    with tab1:
        st.subheader("Create Placement Record")

        if students.empty:
            st.warning("Add students before creating placement records.")
        else:
            with st.form("add_placement_form"):

                student_options = {
                    f"{row['roll_no']} | {row['department']}": row["student_id"]
                    for _, row in students.iterrows()
                }

                selected_student = st.selectbox(
                    "Select Student",
                    list(student_options.keys())
                )

                company = st.text_input("Company Name")
                job_role = st.text_input("Job Role")

                c1, c2 = st.columns(2)

                with c1:
                    package = st.number_input(
                        "Package (LPA)",
                        min_value=0.0,
                        step=0.5
                    )

                with c2:
                    placement_date = st.date_input(
                        "Application Date",
                        value=date.today()
                    )

                status = st.selectbox(
                    "Placement Status",
                    ["Applied", "Interview", "Offered", "Placed",
                     "Rejected", "Withdrawn"]
                )

                submitted = st.form_submit_button(
                    "Add Placement Record",
                    use_container_width=True
                )

                if submitted:
                    if not company.strip() or not job_role.strip():
                        st.error("Company and job role are required.")
                    elif status == "Placed" and package <= 0:
                        st.error("A positive package is required for a placed student.")
                    else:
                        try:
                            add_placement(
                                student_options[selected_student],
                                company.strip(),
                                job_role.strip(),
                                package if package > 0 else None,
                                placement_date,
                                status
                            )
                            st.success("Placement record added successfully!")
                            st.rerun()
                        except Exception as e:
                            st.error(f"Unable to add placement: {e}")

    with tab2:
        st.subheader("Placement Records")

        if placements.empty:
            st.info("No placement records available.")
        else:
            search = st.text_input(
                "Search by roll number, company or role",
                key="placement_search"
            )

            filtered = placements.copy()

            if search:
                mask = (
                    filtered["roll_no"].astype(str).str.contains(search, case=False, na=False)
                    | filtered["company"].astype(str).str.contains(search, case=False, na=False)
                    | filtered["job_role"].astype(str).str.contains(search, case=False, na=False)
                )
                filtered = filtered[mask]

            st.dataframe(
                filtered,
                use_container_width=True,
                hide_index=True
            )

            st.caption(f"{len(filtered)} placement records found")

            placement_ids = filtered["placement_id"].tolist()

            if placement_ids:
                selected_id = st.selectbox(
                    "Select record to edit",
                    placement_ids,
                    key="edit_placement_id"
                )

                record = filtered[
                    filtered["placement_id"] == selected_id
                ].iloc[0]

                with st.form("edit_placement_form"):

                    company_edit = st.text_input(
                        "Company",
                        value=str(record["company"])
                    )

                    role_edit = st.text_input(
                        "Job Role",
                        value=str(record["job_role"])
                    )

                    package_value = record["package_lpa"]
                    package_value = float(package_value) if package_value is not None else 0.0

                    package_edit = st.number_input(
                        "Package (LPA)",
                        min_value=0.0,
                        value=max(package_value, 0.0),
                        step=0.5
                    )

                    date_value = record["placement_date"]

                    if hasattr(date_value, "date"):
                        date_value = date_value.date()

                    date_edit = st.date_input(
                        "Placement Date",
                        value=date_value or date.today()
                    )

                    status_options = [
                        "Applied", "Interview", "Offered",
                        "Placed", "Rejected", "Withdrawn"
                    ]

                    current_status = str(record["status"])
                    status_edit = st.selectbox(
                        "Status",
                        status_options,
                        index=status_options.index(current_status)
                        if current_status in status_options else 0
                    )

                    update_clicked = st.form_submit_button(
                        "Save Changes",
                        use_container_width=True
                    )

                    if update_clicked:
                        if not company_edit.strip() or not role_edit.strip():
                            st.error("Company and role are required.")
                        elif status_edit == "Placed" and package_edit <= 0:
                            st.error("A positive package is required for a placed student.")
                        else:
                            try:
                                update_placement(
                                    selected_id,
                                    company_edit.strip(),
                                    role_edit.strip(),
                                    package_edit if package_edit > 0 else None,
                                    date_edit,
                                    status_edit
                                )
                                st.success("Placement record updated!")
                                st.rerun()
                            except Exception as e:
                                st.error(f"Unable to update record: {e}")

    with tab3:
        st.subheader("Remove Placement Record")

        if placements.empty:
            st.info("There are no placement records to delete.")
        else:
            delete_id = st.selectbox(
                "Select Placement ID",
                placements["placement_id"].tolist(),
                key="delete_placement_id"
            )

            selected_record = placements[
                placements["placement_id"] == delete_id
            ].iloc[0]

            st.write(
                f"**Student:** {selected_record['roll_no']}  "
                f" | **Company:** {selected_record['company']}"
            )

            confirm = st.checkbox(
                "I confirm that I want to delete this placement record."
            )

            if st.button("Delete Placement", disabled=not confirm):
                try:
                    delete_placement(delete_id)
                    st.success("Placement record deleted.")
                    st.rerun()
                except Exception as e:
                    st.error(f"Unable to delete record: {e}")