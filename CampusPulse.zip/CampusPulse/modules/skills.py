from database.connection import get_connection


def add_skill(skill_name):

    connection = get_connection()

    if connection is None:
        raise ConnectionError("Database connection failed.")

    cursor = None

    try:
        cursor = connection.cursor()

        cursor.execute(
            "INSERT INTO skills (skill_name) VALUES (%s)",
            (skill_name.strip(),)
        )

        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        if cursor:
            cursor.close()
        connection.close()


def assign_skill(student_id, skill_id):

    connection = get_connection()

    if connection is None:
        raise ConnectionError("Database connection failed.")

    cursor = None

    try:
        cursor = connection.cursor()

        cursor.execute("""
            INSERT INTO student_skills (student_id, skill_id)
            VALUES (%s, %s)
        """, (student_id, skill_id))

        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        if cursor:
            cursor.close()
        connection.close()


def remove_skill(student_id, skill_id):

    connection = get_connection()

    if connection is None:
        raise ConnectionError("Database connection failed.")

    cursor = None

    try:
        cursor = connection.cursor()

        cursor.execute("""
            DELETE FROM student_skills
            WHERE student_id = %s AND skill_id = %s
        """, (student_id, skill_id))

        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        if cursor:
            cursor.close()
        connection.close()