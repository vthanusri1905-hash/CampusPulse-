import streamlit as st
from database.connection import get_connection


def add_student(roll_no, department, graduation_year, eligible):

    connection = get_connection()

    if connection is None:
        raise ConnectionError("Database connection failed.")

    try:
        cursor = connection.cursor()

        cursor.execute("""
            INSERT INTO students
            (roll_no, department, graduation_year, eligible_for_placement)
            VALUES (%s, %s, %s, %s)
        """, (roll_no, department, graduation_year, eligible))

        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        cursor.close()
        connection.close()


def update_student(student_id, roll_no, department, graduation_year, eligible):

    connection = get_connection()

    if connection is None:
        raise ConnectionError("Database connection failed.")

    try:
        cursor = connection.cursor()

        cursor.execute("""
            UPDATE students
            SET roll_no = %s,
                department = %s,
                graduation_year = %s,
                eligible_for_placement = %s
            WHERE student_id = %s
        """, (
            roll_no,
            department,
            graduation_year,
            eligible,
            student_id
        ))

        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        cursor.close()
        connection.close()


def delete_student(student_id):

    connection = get_connection()

    if connection is None:
        raise ConnectionError("Database connection failed.")

    try:
        cursor = connection.cursor()

        connection.start_transaction()

        cursor.execute(
            "DELETE FROM placements WHERE student_id = %s",
            (student_id,)
        )

        cursor.execute(
            "DELETE FROM student_skills WHERE student_id = %s",
            (student_id,)
        )

        cursor.execute(
            "DELETE FROM students WHERE student_id = %s",
            (student_id,)
        )

        connection.commit()

    except Exception:
        connection.rollback()
        raise

    finally:
        cursor.close()
        connection.close()
def show_student_management(students):

    st.title("Student Management")
    st.caption("Manage student profiles and placement eligibility.")

    tab1, tab2, tab3 = st.tabs([
        "Add Student",
        "Manage Students",
        "Delete Student"
    ])

    with tab1:
        st.subheader("Register New Student")

        with st.form("add_student_form"):

            roll_no = st.text_input("Roll Number")
            department = st.selectbox(
                "Department",
                ["CSE", "CSE (AI & DS)", "CSE (AI & ML)",
                 "ECE", "EEE", "Mechanical", "Civil", "Other"]
            )

            graduation_year = st.number_input(
                "Graduation Year",
                min_value=2026,
                max_value=2040,
                value=2028
            )

            eligible = st.checkbox(
                "Eligible for Placement",
                value=True
            )

            submitted = st.form_submit_button(
                "Add Student",
                use_container_width=True
            )

            if submitted:
                if not roll_no.strip():
                    st.error("Roll number is required.")
                else:
                    try:
                        add_student(
                            roll_no.strip(),
                            department,
                            graduation_year,
                            eligible
                        )
                        st.success("Student added successfully!")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Unable to add student: {e}")

    with tab2:
        st.subheader("Student Records")

        search = st.text_input(
            "Search by Roll Number or Department",
            key="student_search"
        )

        filtered = students.copy()

        if search:
            filtered = filtered[
                filtered["roll_no"].astype(str).str.contains(
                    search, case=False, na=False
                ) |
                filtered["department"].astype(str).str.contains(
                    search, case=False, na=False
                )
            ]

        st.dataframe(
            filtered,
            use_container_width=True,
            hide_index=True
        )

        st.caption(f"{len(filtered)} student records found")

        if not filtered.empty:

            student_id = st.selectbox(
                "Select Student to Edit",
                filtered["student_id"].tolist(),
                key="edit_student_id"
            )

            record = filtered[
                filtered["student_id"] == student_id
            ].iloc[0]

            with st.form("edit_student_form"):

                new_roll = st.text_input(
                    "Roll Number",
                    value=str(record["roll_no"])
                )

                new_department = st.text_input(
                    "Department",
                    value=str(record["department"])
                )

                new_year = st.number_input(
                    "Graduation Year",
                    min_value=2026,
                    max_value=2040,
                    value=int(record["graduation_year"])
                )

                new_eligible = st.checkbox(
                    "Eligible for Placement",
                    value=bool(record["eligible_for_placement"])
                )

                update = st.form_submit_button(
                    "Save Student Changes",
                    use_container_width=True
                )

                if update:
                    if not new_roll.strip() or not new_department.strip():
                        st.error("Roll number and department are required.")
                    else:
                        try:
                            update_student(
                                student_id,
                                new_roll.strip(),
                                new_department.strip(),
                                new_year,
                                new_eligible
                            )
                            st.success("Student details updated!")
                            st.rerun()
                        except Exception as e:
                            st.error(f"Unable to update student: {e}")

    with tab3:
        st.subheader("Remove Student")

        if students.empty:
            st.info("No student records available.")
        else:
            delete_id = st.selectbox(
                "Select Student",
                students["student_id"].tolist(),
                format_func=lambda x: (
                    students.loc[
                        students["student_id"] == x, "roll_no"
                    ].iloc[0]
                ),
                key="delete_student_id"
            )

            selected = students[
                students["student_id"] == delete_id
            ].iloc[0]

            st.write(f"**Roll Number:** {selected['roll_no']}")
            st.write(f"**Department:** {selected['department']}")

            st.warning(
                "Deleting this student also deletes their placement "
                "records and assigned skills."
            )

            confirm = st.checkbox(
                "I confirm that I want to delete this student."
            )

            if st.button("Delete Student", disabled=not confirm):
                try:
                    delete_student(delete_id)
                    st.success("Student deleted successfully!")
                    st.rerun()
                except Exception as e:
                    st.error(f"Unable to delete student: {e}")
